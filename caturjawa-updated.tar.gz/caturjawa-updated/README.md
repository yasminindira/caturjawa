# Catur Jawa

Permainan catur klasik dengan tampilan hangat bernuansa budaya Jawa.

## Fitur
- Lawan Komputer (AI sederhana)
- Mode 2 Pemain
- Bidak berbentuk (gambar)
- SEO friendly
- Proteksi dasar terhadap inspeksi

## Deploy
Push ke branch main, GitHub Pages akan otomatis update dari folder root.

## Assets
- pieces/: gambar bidak
- favicon.ico, robots.txt, sitemap.xml
